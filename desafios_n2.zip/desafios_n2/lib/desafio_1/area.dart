abstract class Area {
  void mostrarArea();
}
