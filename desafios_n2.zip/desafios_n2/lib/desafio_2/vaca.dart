import 'animal.dart';

class Vaca extends Animal {

  @override
  void realizarComportamento() {
    print('A vaca é um mamífero herbívoro domesticado, conhecido por produzir leite, tem um comportamento gregário e é frequentemente criada para produção de carne e derivados lácteos. E ela está jogando leite em você.');
  }
}
