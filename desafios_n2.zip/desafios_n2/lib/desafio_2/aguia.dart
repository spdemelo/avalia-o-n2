import 'animal.dart';

class Aguia extends Animal {

  @override
  void realizarComportamento() {
    print('A águia possui visão aguçada, bico curvo e garras afiadas. E ela está voando agora.');
  }
}
