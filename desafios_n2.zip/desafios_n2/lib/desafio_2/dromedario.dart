import 'animal.dart';

class Dromedario extends Animal {

  @override
  void realizarComportamento() {
    print('O dromedário possui uma corcova nas costas, é adaptado a ambientes áridos, capaz de armazenar água e é frequentemente utilizado como meio de transporte em regiões desérticas. E ele está sendo confundido com um camelo agora.');
  }
}
