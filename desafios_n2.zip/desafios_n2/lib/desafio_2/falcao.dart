import 'animal.dart';

class Falcao extends Animal {

  @override
  void realizarComportamento() {
    print('O falcão é uma ave de rapina diurna com visão aguçada, asas longas e afiladas para voos rápidos, sendo um predador eficiente que caça outras aves. E ele está ouvindo a música tubarão te amo agora.');
  }
}
