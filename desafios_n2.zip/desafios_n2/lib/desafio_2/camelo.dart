import 'animal.dart';

class Camelo extends Animal {

  @override
  void realizarComportamento() {
    print('O camelo é herbívero e possui 2 corcovas. E ele está jogando areia em você agora.');
  }
}
