import 'animal.dart';

class Cabra extends Animal {

  @override
  void realizarComportamento() {
    print('A cabra é herbívera e ruminando, apresenta barba e corno. E ela está subindo numa árvore agora.');
  }
}
