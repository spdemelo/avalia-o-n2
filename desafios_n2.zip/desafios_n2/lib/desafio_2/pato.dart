import 'animal.dart';

class Pato extends Animal {

  @override
  void realizarComportamento() {
    print('O pato é uma ave aquática com uma variedade de cores de plumagem, é especializado na natação e tem uma peculiaridade na vocalização. E ele está fazendo quack quack agora.');
  }
}
