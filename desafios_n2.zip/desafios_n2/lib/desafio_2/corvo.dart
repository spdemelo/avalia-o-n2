import 'animal.dart';

class Corvo extends Animal {

  @override
  void realizarComportamento() {
    print('O corvo tem plumagem preta, é altamente inteligente, tem hábitos oportunistas na alimentação e emite vocalizações complexas. E ele está fazendo AAAAAAAAAA agora.');
  }
}
