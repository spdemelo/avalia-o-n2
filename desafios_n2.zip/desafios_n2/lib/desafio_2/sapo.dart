import 'animal.dart';

class Sapo extends Animal {

  @override
  void realizarComportamento() {
    print('O sapo é um anfíbio que geralmente tem uma pele áspera e verrugosa, vive em ambientes aquáticos ou próximos a eles, e emite sons distintos durante o acasalamento. E ele está beijando a princesa Tiana agora.');
  }
}
