import 'animal.dart';

class Elefante extends Animal {

  @override
  void realizarComportamento() {
    print('O elefante se destaca por seu enorme tamanho, grandes orelhas e uma tromba alongada e flexível. Vive em grupos familiares, exibe uma complexidade social e possui uma excelente memória. E ele está jogandoo água com a sua tromba agora.');
  }
}
