import 'animal.dart';

class Hipopotamo extends Animal {

  @override
  void realizarComportamento() {
    print('O hipopótamo é um animal de grande porte, habitante de ambientes aquáticos, tem uma pele espessa, vive em grupos sociais e é conhecido por ser um dos animais mais agressivos da África. E ele está comando uma watermelon agora.');
  }
}
