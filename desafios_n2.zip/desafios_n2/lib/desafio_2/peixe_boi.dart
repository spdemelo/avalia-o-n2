import 'animal.dart';

class PeixeBoi extends Animal {

  @override
  void realizarComportamento() {
    print('O peixe-boi é um mamífero marinho herbívoro, possui um corpo grande e arredondado, e é conhecido por sua natureza dócil e comportamento tranquilo. E ele está fofo agora.');
  }
}
