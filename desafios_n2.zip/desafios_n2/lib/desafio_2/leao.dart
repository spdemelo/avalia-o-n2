import 'animal.dart';

class Leao extends Animal {

  @override
  void realizarComportamento() {
    print('O leão é um grande felino conhecido por sua juba nos machos, vive em grupos sociais chamados de "coalizões", é um predador que caça em equipe e lidera uma hierarquia dentro da sua comunidade. E ele está sendo o rei da selva agora.');
  }
}
