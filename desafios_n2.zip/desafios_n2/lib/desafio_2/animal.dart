class Animal {

  void realizarComportamento () {}
}
