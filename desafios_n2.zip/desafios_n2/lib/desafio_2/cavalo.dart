import 'animal.dart';

class Cavalo extends Animal {

  @override
  void realizarComportamento() {
    print('O cavalo é um quadrúpede e apresenta um dedo em cada pata, sendo esse revestido, em sua última falange, por um casco único. E ele está dando um coice agora.');
  }
}
