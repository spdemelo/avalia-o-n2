import 'animal.dart';

class Gato extends Animal {

  @override
  void realizarComportamento() {
    print('O gato possui uma pelagem variada em cores e padrões, exibe agilidade e destreza notáveis, tem um comportamento caçador e a capacidade de purr (ronronar). E ele está arranhando o sofá.');
  }
}
