import 'animal.dart';

class Castor extends Animal {

  @override
  void realizarComportamento() {
    print('O castor é um roedor, com corpo maciço e compacto. E ele está roendo a sua perna agora.');
  }
}
