import 'animal.dart';

class Galinha extends Animal {

  @override
  void realizarComportamento() {
    print('A galinha tem penas geralmente em tons de marrom, é domesticada para produção de ovos e carne, possui comportamento de busca por alimentos no solo e estabelece uma estrutura social hierárquica em grupos (galinheiro). E ela está botando um ovo agora.');
  }
}
